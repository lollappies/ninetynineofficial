# Assets Folder

This folder is for additional assets (fonts, icons, etc.)

## Current project structure:
- `index.html`   — Main HTML file (open this in browser)
- `style.css`    — All CSS styles
- `main.js`      — All JavaScript
- `images/`      — All product images (img_001.jpg to img_051.jpg)
- `pages/`       — Reference files for each page section
- `assets/`      — Additional assets (this folder)

## How to run:
1. Open VS Code
2. Open the project folder
3. Right-click `index.html` → Open with Live Server

## EmailJS Setup (for order confirmation emails):
1. Register at https://www.emailjs.com (free)
2. Open `main.js`
3. Find and fill:
   - EMAILJS_SERVICE_ID
   - EMAILJS_TEMPLATE_ID  
   - EMAILJS_PUBLIC_KEY
